RELION 4.0.1 with support for composite masks
============

## Installation
Please follow the instructions at https://github.com/3dem/relion

## How to use composite masks
Add these additional arguments to relion_refine for 3D classification or 3D auto-refine

--solvent_mask path_to_the_protein_mask --lowpass_mask_micelle path_to_the_mask_of_the_whole_paticle_including_the_micelle --lowpass 20
